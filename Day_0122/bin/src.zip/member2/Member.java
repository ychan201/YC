package member2;

public class Member {
	String name,year,bunho,S;
	int nai;
	Member(){}
	
	Member(String name,String year, String bunho){
		this.name=name;
		this.year=year;
		this.bunho=bunho;
	}
}
