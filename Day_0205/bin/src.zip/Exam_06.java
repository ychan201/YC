import java.util.ArrayList;
import java.util.List;

public class Exam_06 {
	public static void main(String[] args) {
		List list = new ArrayList();
		
		list.add("aaa");list.add("abfgdfs");list.add("aasdsaa");list.add("azxcaa");
		
		System.out.println("list.length = "+((String)list.get(0)).length());
	}
}
